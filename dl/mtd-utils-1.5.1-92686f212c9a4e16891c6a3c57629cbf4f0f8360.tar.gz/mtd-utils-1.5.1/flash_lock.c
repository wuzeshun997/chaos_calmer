/*
 * flash_{lock,unlock}
 *
 * utilities for locking/unlocking sectors of flash devices
 */

#define PROGRAM_NAME "flash_lock"
#include "flash_unlock.c"
